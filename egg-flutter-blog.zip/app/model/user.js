'use strict';

module.exports = app => {
    const {
        STRING,
        INTEGER,
        DATE,
    } = app.Sequelize;

    const BlogType = app.model.define('users', {
        id: { type: INTEGER, primaryKey: true, autoIncrement: true },
        username: STRING(255),
        password: STRING(255),
        email: STRING(255),
        created_at: DATE,
        updated_at: DATE,
        jwt: STRING(255),

    });
    BlogType.associate = function () {
        app.model.BlogType.belongsTo(app.model.BlogArticle, { foreignKey: 'id', targetKey: 'typeid' })
    }

    return BlogType;
};