
module.exports = app => {
    const checktoken = app.middleware.jwt();
    const { router, controller } = app
    router.post('/user/checkLogin', controller.user.user.checkLogin)
    router.post('/user/comment', controller.user.user.comment)
}