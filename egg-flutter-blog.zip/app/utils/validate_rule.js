const loginRule = {
    userName: 'string',
    passWord: 'string',
    // pw: {
    //     type: 'String',
    //     required: true,
    // },
}

module.exports = {
    loginRule,
}