'use strict'

const Controller = require('egg').Controller;
const { loginRule } = require('../../utils/validate_rule')
const { signToken } = require('../../utils/handle_token')

// const { validateLogin } = require('../../utils/validators')

class UserController extends Controller {
    async checkLogin() {
        const { ctx } = this;
        let params = ctx.request.body
        try {
            ctx.validate(loginRule, params)
        } catch (error) {
            ctx.body = { status: 400, message: error }
            return
        }
        const res = await this.service.user.user.checkLogin(params)

        if (res.data) {
            let data = signToken(res, this.config.jwt.secret)
            console.log(data.token);
            console.log(params.userName);

            await this.service.user.user.saveToken(data.token, params.userName)
            ctx.body = { 'status': 200, 'data': '登录成功', ...data }
        }
        else {
            ctx.body = { 'status': 403, 'message': '用户名或密码错误' }
        }


    }

    async comment() {
        const { ctx } = this
        let params = ctx.request.body
        ctx.body = await this.service.user.user.saveComent(params)
    }
}

module.exports = UserController