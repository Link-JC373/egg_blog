'use strict';

const Service = require('egg').Service;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
function toInt(str) {
    if (typeof str === 'number') return str;
    if (!str) return str;
    return parseInt(str, 10) || 0;
}
class HomeService extends Service {

    //根据文章id获取文章
    async getArticleById(id) {
        const { ctx } = this
        const result = await ctx.model.BlogArticle.findByPk(toInt(id));
        return { data: result }
    }

    //搜索
    async searchArticle(params) {
        // console.log(searchContent + '============================');
        const { searchContent, pageNum = 0, pageSize = 10, articleTypeId } = params
        let searchParams = []
        let typeParams = []
        console.log(searchContent);
        if (searchContent) {
            searchParams.push({
                title: {
                    [Op.like]: `%${searchContent}%`
                }
            })
        }
        if (articleTypeId) {
            typeParams.push({
                id: articleTypeId
            })
        }


        const { ctx } = this
        const result = await ctx.model.BlogArticle.findAndCountAll({
            where: {
                [Op.and]: searchParams
            },
            attributes: ['id', 'title'],
            include: [
                {
                    where: {
                        [Op.and]: typeParams

                    },

                    model: ctx.model.BlogType,

                    attributes: ['typename']
                }
            ],
            order: [['id']],
            limit: toInt(pageSize),
            offset: toInt(pageNum) * 10,
        })
        return { data: result }

    }

    async getArticleByType() {
        const { ctx } = this
        const result = await ctx.model.BlogType.findAll({
            attributes: ['typename']
        })
        console.log(result);

        return { data: result }
    }

}

module.exports = HomeService;
