const JWT = require('jsonwebtoken')

module.exports = options => {
    return async function (ctx, next) {
        // console.log(ctx);

        //拿到穿回数据的header 中的token值
        const token = ctx.request.header['token']
        // const token = ctx.request.body
        const method = ctx.method.toLowerCase()

        //当前请求时 get 请求 ，执行接下来的中间件
        // if (method === 'get') {
        //     await next()
        // } else
        // console.log(token);

        if (!token) {

            ctx.body = { status: 401, message: '未登录，请登录' }

        } else {
            //当前token存在
            try {
                // decode = JWT.verify(token, options.secret)
                // console.log(decode);
                // // if (!decode || !decode.userName) {
                // //     return ctx.body = { code: 401, message: '没有权限，请登录' }
                // // }
                // if (Date.now() - decode.exp > 0) {
                //     return ctx.body = { status: 401, message: '登录已过期,请重新登录' }
                // }
                // // const user = await ctx.model.User.find({
                // //     userName: decode.userName
                // // })
                // // if (user) {
                // //     await next()
                // // } else {
                // //     ctx.body = { code: 401, message: '用户信息验证失败,请重新登录' }
                // // }
                JWT.verify(token, options.secret, async (err, decode) => {
                    if (err) {
                        console.log(err, 'err');
                    } else {
                        console.log(decode.exp, 'jwtdata');
                        if (!decode.userName) {
                            return ctx.body = { code: 401, message: '没有权限，请登录' }
                        }
                        if (Math.round(new Date() / 1000) - decode.exp > 0) {
                            // console.log(Date.now());

                            return ctx.body = { status: 401, message: '登录已过期,请重新登录' }
                        }
                        else {
                            const user = await ctx.model.User.findOne({
                                where: {
                                    username: decode.userName,
                                }
                            })
                            if (user) {
                                await next()
                            }
                            else {
                                ctx.body = { code: 401, message: '用户信息验证失败,请重新登录' }
                            }
                        }
                    }
                })
            } catch (error) {
                console.log(error);

            }

        }
    }
}