// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminMain = require('../../../app/controller/admin/main');
import ExportDefaultHome = require('../../../app/controller/default/home');
import ExportUserUser = require('../../../app/controller/user/user');

declare module 'egg' {
  interface IController {
    admin: {
      main: ExportAdminMain;
    }
    default: {
      home: ExportDefaultHome;
    }
    user: {
      user: ExportUserUser;
    }
  }
}
