// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBlogArticle = require('../../../app/model/blog_article');
import ExportBlogType = require('../../../app/model/blog_type');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    BlogArticle: ReturnType<typeof ExportBlogArticle>;
    BlogType: ReturnType<typeof ExportBlogType>;
    User: ReturnType<typeof ExportUser>;
  }
}
