// This file is created by egg-ts-helper@1.25.6
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportAdminMain = require('../../../app/service/admin/main');
import ExportDefaultHome = require('../../../app/service/default/home');
import ExportUserUser = require('../../../app/service/user/user');

declare module 'egg' {
  interface IService {
    admin: {
      main: ExportAdminMain;
    }
    default: {
      home: ExportDefaultHome;
    }
    user: {
      user: ExportUserUser;
    }
  }
}
